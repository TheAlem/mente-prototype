import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "MENTE | Orientación en salud mental",
  description: "Orientación, educación y acceso a recursos de salud mental.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es">
      <body className="antialiased">{children}</body>
    </html>
  );
}
